import React, { Component } from 'react';
import './App.css';
var data = require('./users.json'); 

console.log(data);
class App extends Component {
  constructor() {
    super();
    this.handleChange = this.handleChange.bind(this);
  }

  render() {
    return (
      <div className="center">
        <div className="card">
          <h1>Login</h1>
          <form>
            <div>
            <input
              className="form-item"
              placeholder="Email"
              name="username"
              type="text"
              onChange={this.handleChange}
            /></div>
            <div>
            <input
              className="form-item"
              placeholder="Password"
              name="password"
              type="password"
              onChange={this.handleChange}
            /></div><div>
            <input className="form-submit" value="SUBMIT" type="submit" />
            </div>
          </form>
        </div>
      </div>
    );
  }
  handleChange(e) {
    this.setState({
      [e.target.name]: e.target.value
    });
  }
}

export default App;
